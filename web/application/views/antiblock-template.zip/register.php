<?php include ("header.php");?>

<div class="page-nonindex container">
  
  <div class="form-login form-register">
    <div>
      <h1 class="title">Register Form</h1>
      <ul class="clearenter">
        <li>
          <span>Name</span>
          <div class="field"><input name="name" type="text" /></div>
        </li>
        <li>
          <span>Username</span>
          <div class="field"><input name="uname" type="text" /></div>
        </li>
        <li>
          <span>Email</span>
          <div class="field"><input name="email" type="text" /></div>
        </li>
        <li>
          <span>Confirm Email</span>
          <div class="field"><input name="cemail" type="text" /></div>
        </li>
        <li>
          <span>Phone</span>
          <div class="field"><input name="phone" type="text" /></div>
        </li>
        <li>
          <span>Password</span>
          <div class="field"><input name="pass" type="password" /></div>
        </li>
        <li>
          <span>Confirm Password</span>
          <div class="field"><input name="cpass" type="password" /></div>
        </li>
        <li class="capcha full">
          Capcha Here
        </li>
        <li class="term full">
          By clicking Sign Up, you agree to our <a href="#">Terms</a> and that you have read our <a href="#">Data Policy</a>.
        </li>
        <li class="button full">
          <input name="register" class="btn" value="Register" type="button" onclick="location.href='index.php';" />
        </li>
      </ul>
    </div>
  </div>
  
</div>

<?php include ("footer.php");?>