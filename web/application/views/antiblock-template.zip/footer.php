</section>

<footer>
  <div class="bottom-copyright">
    <div class="container">Antiblock &copy;2015 - All Right Reserved</div>
  </div>
</footer>

<div class="btt" title="Return To Top">
  <ul>
    <li><div class="button-btt"></div></li>
  </ul>
</div>
<script src='js/rancak.js' type='text/javascript'></script>
</body>
</html>
