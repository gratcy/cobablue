<?php include ("header.php");?>

<div class="page-nonindex container">
  
  <div class="form-login">
    <div>
      <h1 class="title">Forgot Password Form</h1>
      <ul>
        <li>
          <span>New Password</span>
          <div class="field"><input name="npass" type="password" /></div>
        </li>
        <li>
          <span>Confirm New Password</span>
          <div class="field"><input name="cnpass" type="password" /></div>
        </li>
        <li class="button">
          <input name="forgot" class="btn" value="Submit" type="button" onclick="location.href='index.php';" />
        </li>
      </ul>
    </div>
  </div>
  
</div>

<?php include ("footer.php");?>