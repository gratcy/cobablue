<?php include ("header.php");?>

<div class="page-nonindex container">
  
  <div class="form-login">
    <div>
      <h1 class="title">Login Form</h1>
      <ul>
        <li>
          <span>Username</span>
          <div class="field"><input name="uname" type="text" /></div>
        </li>
        <li>
          <span>Password</span>
          <div class="field"><input name="pass" type="password" /></div>
        </li>
        <li class="remember">
          <input name="remember" type="checkbox" value="" /> <b>Remember Me</b>
        </li>
        <li class="button">
          <input name="login" class="btn" value="Login" type="button" onclick="location.href='index.php';" />
        </li>
        <li class="links clearenter">
          <a href="register.php">Create New Account</a>
          <a href="forgot.php">Forgot Password</a>
        </li>
      </ul>
    </div>
  </div>
  
</div>

<?php include ("footer.php");?>