<?php include ("header.php");?>

<div class="page-nonindex container">
  
  <div class="form-login">
    <div>
      <h1 class="title">Forgot Password Form</h1>
      <ul>
        <li>
          <span>Email</span>
          <div class="field"><input name="email" type="text" /></div>
        </li>
        <li class="capcha full">
          Capcha Here
        </li>
        <li class="button">
          <input name="forgot" class="btn" value="Submit" type="button" onclick="location.href='forgot-changepass.php';" />
        </li>
      </ul>
    </div>
  </div>
  
</div>

<?php include ("footer.php");?>